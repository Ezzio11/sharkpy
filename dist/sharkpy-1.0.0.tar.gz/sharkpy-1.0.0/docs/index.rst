Welcome to SharkPy's documentation!
==================================

SharkPy is a friendly machine learning framework with shark-themed feedback.

.. toctree::
   :maxdepth: 2

   installation
   usage
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`